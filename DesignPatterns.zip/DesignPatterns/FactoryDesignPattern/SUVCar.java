package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class SUVCar implements Car {

    String location = "";

    public SUVCar(String location) {
        this.location = location;
    }

    @Override
    public void buildCar() {
        System.out.println("SUV CAR, country = " + location);
    }
}
