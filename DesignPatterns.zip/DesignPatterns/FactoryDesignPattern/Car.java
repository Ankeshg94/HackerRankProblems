package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public interface Car {
    abstract void  buildCar();
}

