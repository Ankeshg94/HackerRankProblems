package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class USAFactory implements  Cloneable{
    public Car getCar(String carType, String location){
        Car result;
        switch (carType) {
            case "small":
                result = new HatchBackCar(location);
                break;
            case "medium":
                result = new SedanCar(location);
                break;
            case "Luxury":
                result = new SUVCar(location);
                break;
            default:
                result = null;
                break;
        }
        return result;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
