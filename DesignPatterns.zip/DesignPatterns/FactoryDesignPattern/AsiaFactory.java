package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class AsiaFactory {
    public Car getCar(String carType, String location){
        Car result;
        switch (carType) {
            case "small":
                result = new HatchBackCar(location);
                break;
            case "medium":
                result = new SedanCar(location);
                break;
            case "Luxury":
                result = new SUVCar(location);
                break;
            default:
                result = null;
                break;
        }
        return result;
    }
}
