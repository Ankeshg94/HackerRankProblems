package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class CarFactory {

    public Car getCar(String carType, String location) {
        Car result;
        switch (location) {
            case "USA":
                result = new USAFactory().getCar(carType, location);
                break;
            case "Asia":
                result = new AsiaFactory().getCar(carType, location);
                break;
            default:
                result = null;
                break;
        }
        return result;
    }
}