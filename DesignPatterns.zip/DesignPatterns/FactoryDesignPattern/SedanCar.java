package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class SedanCar implements Car {

    String location = "";

    public SedanCar(String location) {
        this.location = location;
    }

    @Override
    public void buildCar() {
        System.out.println("Sedan CAR, country = " + location);
    }
}
