package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class FactoryTest {
    public static void main(String[] args) {
        CarFactory factory = new CarFactory();
        factory.getCar("small","USA").buildCar();
        factory.getCar("medium", "Asia").buildCar();
        factory.getCar("Luxury", "USA").buildCar();
    }
}
