package com.ankesh.learning.DesignPatterns.FactoryDesignPattern;

public class HatchBackCar implements Car {

    String location = "";

    public HatchBackCar(String location) {
        this.location = location;
    }

    @Override
    public void buildCar() {
        System.out.println("HatchBack CAR, country = " + location);
    }
}
