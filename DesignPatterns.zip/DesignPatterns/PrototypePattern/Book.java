package com.ankesh.learning.DesignPatterns.PrototypePattern;

public class Book {
    private String id;
    private String authorName;

    public Book(String id, String authorName) {
        this.id = id;
        this.authorName = authorName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id='" + id + '\'' +
                ", authorName='" + authorName + '\'' +
                '}';
    }
}
