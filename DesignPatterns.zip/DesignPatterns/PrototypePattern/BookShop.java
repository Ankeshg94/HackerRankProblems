package com.ankesh.learning.DesignPatterns.PrototypePattern;

import java.util.ArrayList;
import java.util.List;

public class BookShop implements Cloneable{
    private String ShopName;
    private List<Book> books = new ArrayList<>();

    public BookShop(String shopName) {
        ShopName = shopName;

    }
    public String getShopName() {
        return ShopName;
    }

    public void setShopName(String shopName) {
        ShopName = shopName;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    void load(){
        ArrayList<Book> list = new ArrayList<>();
        list.add(new Book("1", "Ankesh"));
        list.add(new Book("2", "Nitesh"));
        list.add(new Book("3", "Lokesh"));
        list.add(new Book("4", "Sanjay"));
        list.add(new Book("5", "Papa"));
        list.add(new Book("6", "Mummy"));
        this.books = list;
    }

    @Override
    public String toString() {
        return "BookShop{" +
                "ShopName='" + ShopName + '\'' +
                ", books=" + books +
                '}';
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}