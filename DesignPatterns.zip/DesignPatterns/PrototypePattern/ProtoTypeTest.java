package com.ankesh.learning.DesignPatterns.PrototypePattern;

public class ProtoTypeTest {

    public static void main(String[] args) throws CloneNotSupportedException {
        BookShop bs = new BookShop("Shop");
        bs.load();

        BookShop bs1 =  (BookShop) bs.clone();

        bs.getBooks().remove(0);
        System.out.println(bs);
        System.out.println(bs1);

    }
}
