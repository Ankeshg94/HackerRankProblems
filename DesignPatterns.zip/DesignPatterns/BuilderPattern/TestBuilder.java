package com.ankesh.learning.DesignPatterns.BuilderPattern;

public class TestBuilder {
    public static void main(String[] args) {
        Phone p = new PhoneBuilder().setCompany("REAL ME")
                .setOs("Adroid")
                .setDisplay("4.5")
                .setWeight("ee")
                .build();
        System.out.println(p);
    }
}
