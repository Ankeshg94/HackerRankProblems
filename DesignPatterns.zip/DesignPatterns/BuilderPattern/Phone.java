package com.ankesh.learning.DesignPatterns.BuilderPattern;

public class Phone {
    private String company;
    private String os;
    private String ram;
    private String display;
    private String  weight;

    public Phone(String company, String os, String ram, String display, String weight) {
        this.company = company;
        this.os = os;
        this.ram = ram;
        this.display = display;
        this.weight = weight;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "company='" + company + '\'' +
                ", os='" + os + '\'' +
                ", ram='" + ram + '\'' +
                ", display='" + display + '\'' +
                ", weight='" + weight + '\'' +
                '}';
    }
}
