package com.ankesh.learning.DesignPatterns.AdapterPattern;

import java.io.File;

public interface Downloader {

    File download(String fileName);
}
