package com.ankesh.learning.DesignPatterns.AdapterPattern;

import java.io.File;

public class GoogleDriveDownloader {

    public File download(String token, String fileName) {
        System.out.println("returned google drive file");
        return new File("");
    }

}
