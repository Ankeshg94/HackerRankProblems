package com.ankesh.learning.DesignPatterns.AdapterPattern;

import java.io.File;

public class SimpleDownloader implements Downloader{

    @Override
    public File download(String fileName) {
        System.out.println("returned simple file");
        return new File("");
    }
}
