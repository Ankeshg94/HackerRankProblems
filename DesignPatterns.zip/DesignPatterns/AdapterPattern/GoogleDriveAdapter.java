package com.ankesh.learning.DesignPatterns.AdapterPattern;

import java.io.File;

public class GoogleDriveAdapter implements Downloader {
    @Override
    public File download(String fileName) {
        GoogleDriveDownloader downloader = new GoogleDriveDownloader();
        String token = "token";
        downloader.download(token, fileName);
        return null;
    }
}
