package com.ankesh.learning.DesignPatterns.AdapterPattern;

public class Client {


    public static void main(String[] args) {
        Downloader downloader = new GoogleDriveAdapter();
        downloader.download("filename");
    }
}
